d = open("write.txt","w")
d.write("the first line\n")
d.close()

# Note: instead of “w“, you can also append using “a“

