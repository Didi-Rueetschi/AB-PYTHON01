# arithmetic operations

#Set variables
a=5
b=3

#calculation
c=a+b
m=a-b
p=a*b
d=a/b

#Output
print("results:", c, m, p, d)


