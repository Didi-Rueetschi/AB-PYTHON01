import urllib.request
# Read the contents of a URL and copy to a file
urllib.request.urlretrieve("http://www.cssgmbh.ch/cssgmbh/Beispiele/url_lesen.htm", "url_copy.htm")
