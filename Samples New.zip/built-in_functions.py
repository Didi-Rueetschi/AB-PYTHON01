# Built-in Functions

t1 = (3, 12, 9)
print("t1:", t1)
print("Max. value:", max(t1))
print("Min. value:", min(t1))
print("sum :", sum(t1))
print("Bytecode character A :", ord("A"))
print("character Bytecode 97:", chr(97))
print("character Bytecode 8364:", chr(8364))

