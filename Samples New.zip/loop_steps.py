# For loop with steps

for i in range(2,20,3):
    if i % 2 == 0:
        print("number", i, "is even")
    else:
        print("number:", i, "is not even:")
