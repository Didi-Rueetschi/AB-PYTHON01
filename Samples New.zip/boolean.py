# Boolean

x = "A"!="B"
print("A!=B:", x)
x = 5<3
print("5<3:", x)
w = 'Hello'
print("w is", bool(w))
w = ''
print("w is", bool(w))
z = 5
if z:
    print("z is", bool(z))
z = 0
if not z:
    print("z is", bool(z))
