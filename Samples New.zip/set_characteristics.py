# generate a set
s1 = set([8, 2, 3, 5, 5, 5, 8])
print("Set:", s1)

# Copy a set
s2 = s1.copy()

# Add an element to a set
s1.add("abc")

# Delete an element from a set
s1.discard(3)

# Empty a set
s1.clear()
