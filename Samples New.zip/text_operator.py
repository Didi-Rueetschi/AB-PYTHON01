# String

a=4
t1 = "part 1"
t2 = "part 2"
ttotal = t1+", "+t2+", "+str(a)
t3 = "-oooo-"
t4 = "***"
tline = t4 + t3 * 3 + t4

if "4" in ttotal:
    print("4: is in "+ttotal+" contains")
print(ttotal)
print(tline)
