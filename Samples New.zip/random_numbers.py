# random numbers

# Import module random
import random

# Initialize random number generator
random.seed()

# random values and calculation
a = random.randint(1,10)
b = random.randint(1,10)
c = a + b

# Output
print("the task:", a, "+", b)
print("Result:", c)
