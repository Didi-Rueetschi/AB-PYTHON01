# Mathematical Functions

# Module math
import math
# Trigonom. Functions and constants
x = 30.0
xbm = x / 180 * math.pi
print("sine ", x, "degree:", math.sin(xbm))
print("cosine", x, "degree:", math.cos(xbm))
print("tangent", x, "degree:", math.tan(xbm))
