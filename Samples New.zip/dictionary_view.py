# Views

# generate a dictionary
alter = {"Peter":31, "Julia":28, "Werner":35}
print(alter)

# Read out single parameters
w = alter.values()
k = alter.keys()
i = alter.items()

# Output
print("Values:", w)
print("Keys: ", k)
print("Items:", i)
