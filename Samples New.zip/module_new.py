def square(x):
    erg = x * x
    return erg
