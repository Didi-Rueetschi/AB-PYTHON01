# Lists

# One dimensional
z=[3000,"Bern",1200,"Lausanne"]
z.append(8000)
z[3]="Geneva"
print(z)
print(z[0])
print(z[3])

# Multi dimensional
x=[[3000,"Bern"],[1200,"Geneva"]]
print(x)
print(x[0])
print(x[1][1])
