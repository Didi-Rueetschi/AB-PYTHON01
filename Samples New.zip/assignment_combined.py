# Assigning operators

x = 6
print("x is:", x)
x += 3
print("x +3 is:", x)
x **= 2
print("x squared is:", x)
x *= 3
print("x times 3 is:", x)
t = "Hello"
t += " Python "+str(x)
print(t)
