# String index

tname = "Robinson Crusoe"
print(tname[5:8])
print(tname[0:8])
print(tname[9:-3])

# Number of elements
print("number elements:", len(tname))

# How many times does "o" occur
print("There are ", tname.count("o"), "o")

# "a"instead of "o"
print(tname.replace("o","a"))
