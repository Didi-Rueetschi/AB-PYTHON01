# Tuple

# One dimensional
z=(3,6,-8,5.5)
print(z)

# Multi dimensional
x=(("Paris","Fr",350), ["Rome","It",420])
print(x)
print(x[0])
print(x[1][1])
