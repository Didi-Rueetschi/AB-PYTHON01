# Open a Browser

import webbrowser
webbrowser.open("http://www.flane.ch\python")
print("End")
