# Numeral systems

a = 12
e = 5.97E+24
print("Decimal:", a)
print("Hexadecimal numerals:", hex(a))
print("Octal:", oct(a))
print("Dual:", bin(a))
print("Float", float(a))
print("Earthmass:", e, "->", int(e), "kg")
